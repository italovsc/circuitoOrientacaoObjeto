package heranca1_1;

abstract class Funcionario {
	String nome;
	String cpf;
	String datanascimento;
	String numDependentes;
	Double salario;
	String senha;
	Boolean isGerenteTI;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getDatanascimento() {
		return datanascimento;
	}
	public void setDatanascimento(String datanascimento) {
		this.datanascimento = datanascimento;
	}
	public String getNumDependentes() {
		return numDependentes;
	}
	public void setNumDependentes(String numDependentes) {
		this.numDependentes = numDependentes;
	}
	public Double getSalario() {
		return salario;
	}
	public void setSalario(Double salario) {
		this.salario = salario;
	}

	
    // Construtor padrão
    public Funcionario() {
        this.nome = "";
        this.cpf = "";
        this.datanascimento = "";
        this.numDependentes = "";
        this.salario = 0.0;
        this.senha = "";
        this.isGerenteTI = false;
    }

    // Construtor específico
    public Funcionario(String nome, String cpf, String datanascimento, String numDependentes, Double salario) {
        this.nome = nome;
        this.cpf = cpf;
        this.datanascimento = datanascimento;
        this.numDependentes = numDependentes;
        this.salario = salario;
        this.senha = "123";
        this.isGerenteTI = false;
    }
    
    public Funcionario(String nome, String cpf, String datanascimento, String numDependentes, Double salario, String senha) {
        this.nome = nome;
        this.cpf = cpf;
        this.datanascimento = datanascimento;
        this.numDependentes = numDependentes;
        this.salario = salario;
        this.senha = senha;
        this.isGerenteTI = false;
    }
	
	abstract Double getBonusAnual();
	
	
	public void saudacao() {
         if (this instanceof CientistaDados) {
            System.out.println("Bem-vinde Cientista de Dados " + this.nome + "!");
        } else if (this instanceof GerenteTI) {
            System.out.println("Bem-vinde Gerente de TI " + this.nome + "!");
        } 
         else if (this instanceof DevFrontEnd){
            System.out.println("Bem-vinde Dev Front end " + this.nome + "!");
        }
         else {
        	 System.out.println("Bem-vinde Funcionário " + this.nome + "!");
         }
    }
   

    public void setSenha(String senha, boolean isGerenteTI) {
        this.senha = senha;
        this.isGerenteTI = isGerenteTI;
    }

    // Metodo para autenticar
    public boolean autentica(String senhaDigitada) {
        return isGerenteTI && senha != null && senha.equals(senhaDigitada);
    }
}





	
