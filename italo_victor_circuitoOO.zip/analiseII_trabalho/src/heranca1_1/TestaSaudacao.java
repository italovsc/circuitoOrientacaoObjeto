package heranca1_1;

public class TestaSaudacao {

	public TestaSaudacao() {
		// TODO Auto-generated constructor stub


        CientistaDados cientista = new CientistaDados("Maria", "12345678903", "01/10/2000", "0", 5000.0, 456);
        cientista.saudacao(); 

        GerenteTI gerente = new GerenteTI( "12345678", 6);
        gerente.saudacao(); 
        
        DevFrontEnd frontend = new DevFrontEnd("Luis", "12345678905", "10/02/1996", "0", 3000.0, 22);
        frontend.saudacao();
        
        AssistenteRH assistente = new AssistenteRH("Fabio", "CPF", "DATAnascimento", "numDependentes", 3330.00, 552, "23412");
        assistente.saudacao();
    
	}

}
