package heranca1_1;

public class TestaAutenticacao {
    public static void main(String[] args) {
    	 GerenteTI gerenteTI = new GerenteTI("nome", "cpf", "dataNascimento", "numDependentes", 2500.00, "ramal", 6, "senha123");
    	  
         
         System.out.println("Autenticação Gerente de TI: " + gerenteTI.autentica("senha123")); // Deve retornar true
   
        
         AssistenteRH assistenteRH = new AssistenteRH("Fabio", "CPF", "DATAnascimento", "numDependentes", 3330.00, 552, "23412");
   
      
         System.out.println("Autenticação Assistente de RH: " + assistenteRH.autentica("23412")); // Deve retornar true
         
        
         AuditorRH	auditor = new AuditorRH("Sergio", "cpf_padrao", "DataPadrao", "numDependentes", 3330.00, 223, "2951");
   
        
         System.out.println("Autenticação Auditor de RH: " + auditor.autentica("2951")); // Deve retornar true
    }
}