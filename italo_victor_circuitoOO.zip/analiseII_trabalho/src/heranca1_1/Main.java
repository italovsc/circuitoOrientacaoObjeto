package heranca1_1;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Funcionario> listaFuncionarios = new ArrayList<>();

       

        CientistaDados cientista = new CientistaDados();
        cientista.setNome("Cientista C");
        listaFuncionarios.add(cientista);

        GerenteTI gerente = new GerenteTI("12345678", 6);
        gerente.setNome("Gerente D");
        listaFuncionarios.add(gerente);
        
        AssistenteRH assistente = new AssistenteRH();
        assistente.setNome("Assistente F");
        listaFuncionarios.add(assistente);

        //lista de funcionarios - iteracao
        for (Funcionario f : listaFuncionarios) {
            System.out.print("Funcionário do tipo: ");
            if (f instanceof CientistaDados) {
                System.out.print("Cientista de Dados");
            } else if (f instanceof GerenteTI) {
                System.out.print("Gerente de TI");
            }
            else if(f instanceof AssistenteRH) {
            	System.out.print("Assistente de RH");
            }
            else {
                System.out.print("Funcionário");
            }
            System.out.println();

            System.out.println("Bem-vindo(a), " + f.getNome() + "!");
        }
    }
}
