package heranca1_1;

public class GerenteTI extends Funcionario implements Autenticavel {

		Integer numFuncionarios;
		String ramal;
		String senha;

	    public GerenteTI(String nome, String cpf, String datanascimento, String numDependentes, Double salario, String ramal, Integer numFuncionarios, String senha) {
	        super(nome, cpf, datanascimento, numDependentes, salario, senha); 
	        this.numFuncionarios = numFuncionarios;
	        this.ramal = ramal;
	    }
	    
	    public GerenteTI(String ramal, Integer numFuncionarios) {
	        super();
	        this.ramal = ramal; 
	        this.numFuncionarios = numFuncionarios; 
	    }

	    
	    // Mwtodo para definir a senha
	    public void setSenha(String senha) {
	        this.senha = senha;
	    }


	
	    
	    @Override
	    public Double getBonusAnual() {
	    return (super.getSalario() * 0.1) * this.numFuncionarios;
	    }

}
