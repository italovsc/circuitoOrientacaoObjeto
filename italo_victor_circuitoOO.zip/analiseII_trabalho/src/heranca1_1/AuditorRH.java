package heranca1_1;

public class AuditorRH implements Autenticavel{

	Integer id;
	String senha;
    public AuditorRH(String nome, String cpf, String datanascimento, String numDependentes, Double salario, Integer id, String senha) {
        super(); 
        this.id = id;
    }
	 
    public AuditorRH() {
        
        super();
       
    }
	  
	    public void setSenha(String senha) {
	        this.senha = senha;
	    }
	    
	    @Override
	    public boolean autentica(String senhaDigitada) {
	        return senhaDigitada.equals(this.senha);
	    }
	 
}
