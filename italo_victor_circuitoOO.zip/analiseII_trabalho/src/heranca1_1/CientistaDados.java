package heranca1_1;

public class CientistaDados extends Funcionario {

		Integer crcd;
		
		 public CientistaDados(String nome, String cpf, String datanascimento, String numDependentes, Double salario, Integer crcd) {
		        super(nome, cpf, datanascimento, numDependentes, salario);
		        this.crcd = crcd;
		    }
		 
		    public CientistaDados() {
		     
		        super();
		    }
		
		@Override
		public Double getBonusAnual() {
		return salario + 500.0;
		}

}
