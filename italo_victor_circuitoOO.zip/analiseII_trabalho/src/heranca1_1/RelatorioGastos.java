package heranca1_1;

public class RelatorioGastos {
    private Double totalSalario;
    private Double totalBonus;

    public RelatorioGastos() {
        this.totalSalario = 0.0;
        this.totalBonus = 0.0;
    }

    public void atualizaValores(Funcionario f) {
        totalSalario += f.getSalario();
        totalBonus += f.getBonusAnual();
    }

    public Double getTotalSalario() {
        return totalSalario;
    }

    public Double getTotalBonus() {
        return totalBonus;
    }
}