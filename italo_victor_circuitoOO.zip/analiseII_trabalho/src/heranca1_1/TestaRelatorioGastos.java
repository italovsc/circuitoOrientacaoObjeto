package heranca1_1;

public class TestaRelatorioGastos {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
        RelatorioGastos relatorio = new RelatorioGastos();

        CientistaDados cientista = new CientistaDados();
        cientista.setSalario(5000.0);
        cientista.setNome("Cientista C");

        GerenteTI gerente = new GerenteTI("12345678", 6);
        gerente.setSalario(6000.0);
        gerente.setNome("Gerente D");
        
        DevFrontEnd frontend = new DevFrontEnd();
        frontend.setSalario(3000.0);
        frontend.setNome("Dev Front End E");
        
        AssistenteRH assistente = new AssistenteRH();
        assistente.setSalario(3330.00);
        assistente.setNome("Assistente F");
        

   
        relatorio.atualizaValores(cientista);
        relatorio.atualizaValores(gerente);
        relatorio.atualizaValores(frontend);
        relatorio.atualizaValores(assistente);
       
        System.out.println("Total gasto em salários: " + relatorio.getTotalSalario());
        System.out.println("Total gasto em bônus: " + relatorio.getTotalBonus());
	}

}
