package heranca1_1;

abstract interface Autenticavel{

   
    public boolean autentica(String senha);
}

