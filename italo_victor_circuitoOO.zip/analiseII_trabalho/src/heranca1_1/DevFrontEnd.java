package heranca1_1;

public class DevFrontEnd extends Funcionario {

	Integer crpw;
	
    public DevFrontEnd(String nome, String cpf, String datanascimento, String numDependentes, Double salario, Integer crpw) {
        super(nome, cpf, datanascimento, numDependentes, salario);
        this.crpw = crpw;
    }
    
    public DevFrontEnd() {
        super();
    }

	@Override
	Double getBonusAnual() {
		// TODO Auto-generated method stub
		return salario*0.1;
	}

    

}
