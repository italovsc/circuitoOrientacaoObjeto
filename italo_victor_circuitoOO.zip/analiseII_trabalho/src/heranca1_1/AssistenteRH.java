package heranca1_1;

public class AssistenteRH extends Funcionario implements Autenticavel{
	Integer id;
	String senha;
    public AssistenteRH(String nome, String cpf, String datanascimento, String numDependentes, Double salario, Integer id, String senha) {
        super(nome, cpf, datanascimento, numDependentes, salario, senha); 
        this.id = id;
    }
	 
    public AssistenteRH() {
       
        super();
       
    }
	  
	    public void setSenha(String senha) {
	        this.senha = senha;
	    }
	 
		@Override
		Double getBonusAnual() {
			// TODO Auto-generated method stub
			return salario*0.1;
		}

}
