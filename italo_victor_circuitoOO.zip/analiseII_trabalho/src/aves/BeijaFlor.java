package aves;

class BeijaFlor extends Passaro {
    @Override
    void pia() {
    }

    @Override
    void canta() {
    }

    @Override
    void voa() {
    }

    void voapratras() {
    }

	@Override
	void anda() {
		// TODO Auto-generated method stub
		
	}
}