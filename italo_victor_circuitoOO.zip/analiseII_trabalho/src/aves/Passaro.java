package aves;

abstract class Passaro extends Ave {
    abstract void canta();
    abstract void voa();
}