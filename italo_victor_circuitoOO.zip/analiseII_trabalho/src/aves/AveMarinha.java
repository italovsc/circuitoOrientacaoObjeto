package aves;

abstract class AveMarinha extends Ave {
    abstract void nada();
}
