package aves;

class Papagaio extends Passaro {
    @Override
    void pia() {
    }

    @Override
    void canta() {
    }

    @Override
    void voa() {
    }

    void fala() {
    }

	@Override
	void anda() {
		// TODO Auto-generated method stub
		
	}
    }

