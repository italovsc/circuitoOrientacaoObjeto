package aves;

class Avestruz extends AveTerrestre {
    @Override
    void pia() {
    }

    void camufla() {
    }

	@Override
	void anda() {
		// TODO Auto-generated method stub
		
	}
}