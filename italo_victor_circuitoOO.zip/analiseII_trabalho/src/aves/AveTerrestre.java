package aves;

abstract class AveTerrestre extends Ave {
   
    void corre() {
    }
}