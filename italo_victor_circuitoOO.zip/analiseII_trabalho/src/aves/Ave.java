package aves;

abstract class Ave {
    String nome;
    Double peso;

    abstract void pia();
    abstract void anda();
}
