package aves;

class Pinguim extends AveMarinha {
    Pinguim conjuge;

    void nada() {
    }

	@Override
	void pia() {
		System.out.println(nome + " pia!!");
		
	}

	@Override
	void anda() {
		System.out.println(nome + " anda!!");
		
	}
}